import React from 'react';
import './App.css';

function About () {
  
  return (
    <div>
      <h1>Welcome to our about page!</h1>
      <br>
      </br>
      <h1>collaboration summary:</h1>
      <p>TBD</p>
    </div>
  )
}

export default About;
