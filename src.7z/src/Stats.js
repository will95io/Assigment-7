import React from 'react';
import './App.css';

function Stats () {
  
  return (
    <div className="App">
      
      <h1>Welcome to our stats page!</h1>
   
      <p>TBD</p>

    </div>
  )
}

export default Stats;
